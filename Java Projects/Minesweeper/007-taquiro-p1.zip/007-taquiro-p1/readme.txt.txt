Tyler John Aquiro
taquiro
G01326064
Lecture: 007
